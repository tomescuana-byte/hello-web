class InvalidType extends Error {
  constructor() {
    super("InvalidType");
    this.name = "InvalidType";
  }
}

function isStringLike(x) {
  return typeof x === "string" || x instanceof String;
}

function distance(s1, s2) {
  if (!isStringLike(s1) || !isStringLike(s2)) {
    throw new InvalidType();
  }

  s1 = s1.toString();
  s2 = s2.toString();

  const n = s1.length;
  const m = s2.length;

  if (n === 0 && m === 0) return 0;

  const table = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));

  for (let i = 0; i <= n; i++) table[i][0] = i;
  for (let j = 0; j <= m; j++) table[0][j] = j;

  for (let i = 1; i <= n; i++) {
    for (let j = 1; j <= m; j++) {
      const sameChar = s1[i - 1] === s2[j - 1] ? 0 : 1;

      const remove = table[i - 1][j] + 1;
      const insert = table[i][j - 1] + 1;
      const replace = table[i - 1][j - 1] + sameChar;

      table[i][j] = Math.min(remove, insert, replace);
    }
  }

  return table[n][m];
}

module.exports = { distance, InvalidType };
